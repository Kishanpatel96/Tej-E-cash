<?php 
include('template/header_outer.php');
 ?>
<section class="main wow fadeInDownBig">
<div class="main__title__container ">
<h1 class="main__title">Farst Network</h1>
<h2 class="main__subtitle">The Best of <span>Decentralized Network</span> <br> programs</h2>
</div>												
<video autoplay loop class="main__video" muted src="/tej/assets/images/outerbackgroundVideo.mp4" poster="https://farstcoin.co/resources/assets/img/home/video_poster.png">
</video>
</section>
<section class="about" style="background: url('https://farstcoin.co/resources/assets/img/home/bg_img2.jpg') top no-repeat;min-height: 100vh; background-size: cover;">
<div class="container">
<div class="about__wrapper wow fadeInDown">
<h3 class="about__title">INTRODUCING <br> <span class="normal__weight">FARST NETWORK</span>
<div class="feature-media media-wrapper" style="margin-top: 10px;width: 100%;">
<iframe src="https://www.youtube.com/embed/83joiZpGt0g" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
</div>
<div class="about__links">
<a href="https://farstcoin.co/signup" rel="nofollow" class="about__link">More About Us
<img src="https://farstcoin.co/resources/assets/img/home/arrow__right.png" height="8" width="15" alt="->" />
</a>
<a href="https://farstcoin.co/signup" rel="nofollow" class="about__link">Careers
<img src="https://farstcoin.co/resources/assets/img/home/arrow__right.png" height="8" width="15" alt="->" />
</a>
</div>
</div>
</div>
</section>
<section class="advantages" style="background-image: url('https://farstcoin.co/resources/assets/img/home/bg_img1.jpg');">
<div class="container">
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_1.png" height="59" width="62" />
</div>
<p class="advantages__card__paragraph">
Special business scope combining financial solutions and ecosystem.
</p>
</div>
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_7.png" height="64" width="62" />
</div>
<p class="advantages__card__paragraph">
Strong Ecosystem allows FRCT payment in various online services.
</p>
</div>
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_5.png" height="57" width="62" />
</div>
<p class="advantages__card__paragraph">
No Emotional TOGC trading signals with high successful rate.
</p>
</div>
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_4.png" height="64" width="64" />
</div>
<p class="advantages__card__paragraph">
Powerful Community with Understanding and Knowledge.
</p>
</div>
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_8.png" height="62" width="66" />
</div>
<p class="advantages__card__paragraph">
High Return Low Risk investment.
</p>
</div>
<div class="advantages__card wow fadeInDown">
<div class="advantages__card__icon">
<img src="https://farstcoin.co/resources/assets/img/home/advantage_2.png" height="62" width="60" />
</div>
<p class="advantages__card__paragraph">
Effective Communication and Technical Support.
</p>
</div>
</div>
</section>
<section class="contract">
<div class="affiliate wow fadeInLeft">
<div class="affiliate__wrapper ">
<div class="affiliate__bg" style="background: linear-gradient(180deg,rgba(52,54,58,.3),rgba(52,54,58,.3)),url('https://farstcoin.co/resources/assets/img/home/affiliate.png') no-repeat 50%;background-size: cover;"></div>
<h4 class="affiliate__title">
TOGC THE OCEAN GARBAGE COLLECTOR <br>
</h4>
<div class="feature-media media-wrapper" style="width: 100%;">
<iframe src="https://www.youtube.com/embed/0rwb7zGKti0" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
</div>
</div>
</div>
<div class="employer wow fadeInRight">
<div class="employer__wrapper ">
<div class="employer__bg" style="background:linear-gradient(180deg,rgba(54, 105, 195, 0.9),rgba(75, 103, 236, 0.9)),url('https://farstcoin.co/resources/assets/img/home/employer.png') no-repeat 50%;background-size: cover;"></div>
<h4 class="employer__title">
TOGC <br>
TABLE REPORT
</h4>
 <table id="show" data-order='[[ 3, "desc" ]]' data-page-length='10' class="table table-striped">
<thead>
<tr>
<th style="color: #33aee2">Market</th>
<th>Buy At</th>
<th>Result</th>
<th>Time end</th>
<th>Status</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
</div>
</div>
</section>
<section class="clients" style="background-image: url('https://farstcoin.co/resources/assets/img/home/bg_img1.jpg')">
<div class="container wow fadeInUp">
<h5 class="clients__title">CHART REPORT TOGC</h5>
<div class="clients__wrapper">
<div id="chartContainer" style="height: 600px; width: 100%;">
</div>
</div>
</div>
</section>
<section class="news-line">
<div class="container">
<div>
<ul id="og-grid" class="og-grid row" style="padding-left: 15px;">

<li class="mix photoshop col-md-3" style="display: inline-block;padding-left: 0px;">
<a href="https://farstcoin.co/new/farst-ico-detail-schedule">
<img src="https://farstcoin.co/public/uploads/1512666885.png" alt="Farst ICO detail schedule">
<div class="hover-mask">
<h3>Farst ICO detail schedule</h3>
</div>
</a>
</li>


<li class="mix photoshop col-md-3" style="display: inline-block;padding-left: 0px;">
<a href="https://farstcoin.co/new/how-to-deposit-and-withdraw">
<img src="https://farstcoin.co/public/uploads/1512669938.png" alt="How to deposit and withdraw?">
<div class="hover-mask">
<h3>How to deposit and withdraw?</h3>
</div>
</a>
</li>


<li class="mix photoshop col-md-3" style="display: inline-block;padding-left: 0px;">
<a href="https://farstcoin.co/new/farst-network-announcement">
<img src="https://farstcoin.co/public/uploads/1512666626.jpg" alt="Farst Network Announcement">
<div class="hover-mask">
<h3>Farst Network Announcement</h3>
</div>
</a>
</li>


<li class="mix photoshop col-md-3" style="display: inline-block;padding-left: 0px;">
<a href="https://farstcoin.co/new/internal-exchange-15-dec-17">
<img src="https://farstcoin.co/public/uploads/1512666586.png" alt="Internal Exchange 15-Dec-17">
<div class="hover-mask">
<h3>Internal Exchange 15-Dec-17</h3>
</div>
</a>
</li>

</ul> 
</div>
</div>
</section>
<section class="partners" style="background-image: url('https://farstcoin.co/resources/assets/img/home/bg_img1.jpg')">
<div class="container wow fadeInUp">
<h5 class="partners__title">Why Farst Network is unique?</h5>
<div class="partners__carousel__container">
<div class="row">
<div class="col-md-6">
<div class="home-trading__subtitle">The Ocean Garbage Collector</div>
<ul class="home-trading__describtion">
<li class="home-trading__item">
TOGC will help us to collect data of all trading pairs in the market, combining technical indicators to create smart algorithms that to determine the buy and sell orders accurately and quickly, ensuring all orders have the highest probability of winning.
</li>
</ul>
</div>
<div class="col-md-6">
<div class="home-trading__subtitle">Ecosystem</div>
<ul class="home-trading__describtion">
<li class="home-trading__item">
Farst Network is Ecosystem Project. We are creating the ecosystem that allow FRCT growth.
</li>
</ul>
</div>
</div>
</div>
</div>
</section>
<section class="behind-click" style="background: linear-gradient(180deg,rgba(197, 26, 50, 0.9),rgba(79, 117, 255, 0.9)), no-repeat 50%;background-size: cover;">
<div class="behind-click__wrapper wow fadeInRight">
<img src="https://farstcoin.co/resources/assets/img/home/quote__icon2.png" alt=" '' " class="behind-click__quote" height="55" width="72" />
<h6 class="behind-click__title">
Investment is always risky.
Like any other investments, the perceive value of farstcoin can fluctuate.
Please read our details and policies before investment.
The strategy of farstcoin may change due to market and compliance requirements of external parties.
The administrator of farstcoin will try to follow the strategy as outline as much as possible; any changes of strategy will be updated asap
We have only one website for announcements and membership registration. All of our social medias will be listed on the website homepage.
Investors are advised to assess the risk of trading in farstcoin as the administrator of this website will take no responsibility for changes in valuation of farstcoin.
</h6>
</div>
</section>

<div id="login-modal" class="modal fade" role="dialog">
<div class="modal-dialog">

<div class="modal-content text-center">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title"><strong>Login</strong></h4>
</div>
<div class="modal-body" style="height: 400px;">
<form method="POST" action="https://farstcoin.co/login" accept-charset="UTF-8" id="login-form"><input name="_token" type="hidden" value="ZFEKirMHLtCis18HLGrL82CvI2mixvkksEZJR1IK">
<div class="form-group">
<label for="email" class="col-md-4 control-label">E-Mail Address</label>
<div class="col-md-6">
<input id="email" type="email" class="form-control" name="email" value="" required autofocus>
</div>
</div>
<div class="form-group">
<label for="password" class="col-md-4 control-label">Password</label>
<div class="col-md-6">
<input id="password" type="password" class="form-control" name="password" required>
</div>
</div>
<div class="form-group">
<label for="secret" class="col-md-4 control-label">2FA Code (Only if you enabled 2FA)</label>
<div class="col-md-6">
<input id="secret" type="text" class="form-control" name="secret">
</div>
</div>
<div class="form-group">
<div class="col-md-6 col-md-offset-3">
<div class="checkbox">
<label>
<input type="checkbox" name="remember"> Remember Me
</label>
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-6 col-md-offset-4">
<button class="btn btn-primary" data-toggle="modal" data-target="#two_fa_form">
Login
</button>
<a class="btn btn-link" href="https://farstcoin.co/password/reset">
Forgot Your Password?
</a>
<a class="btn btn-link" href="https://farstcoin.co/register" style="margin-top: 0px;">
Register a new membership
</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>

<?php include('template/footer_outer.php'); ?>