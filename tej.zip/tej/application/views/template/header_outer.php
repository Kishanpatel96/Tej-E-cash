<!doctype html>
<html lang="en">
<head>
<title>Farst Network - The Best of Decentralized Network</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Farst Network - The Best of Decentralized Network">
<meta name="keywords" content="Farstcoin,  Farst coin, Farstnetwork, Farst Network, Farst network lending">
<meta name="author" content="FarstCoin Team">

<script type="text/javascript">
//<![CDATA[
window.__cfRocketOptions = {byc:0,p:0,petok:"3bbfea3aa5c3c3f5b5827ecb5e8b745b5e9761ae-1519749709-1800"};
//]]>
</script>
<script type="text/javascript" src="/tej/assets/js/rocket.min.js"></script>
<link rel="apple-touch-icon" sizes="180x180" href="">
<link rel="icon" type="image/png" sizes="32x32" href="">
<link rel="icon" type="image/png" sizes="16x16" href="">
<link rel="manifest" href="img/favicon/manifest.json">
<link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
<meta name="theme-color" content="#ffffff">


<link rel="shortcut icon" type="image/x-icon" href="https://farstcoin.co/resources/assets/img/logo.png" />

<script id="_wau7a4" type="text/rocketscript">var _wau = _wau || []; _wau.push(["classic", "bl6m2fusuppj", "7a4"]);
        (function() {var s=document.createElement("script"); s.async=true;
        s.src="//widgets.amung.us/classic.js";
        document.getElementsByTagName("head")[0].appendChild(s);
        })();</script>

<script type="text/rocketscript">
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '892008190947941');
          fbq('track', 'PageView');
        </script>
<noscript><img height="1" width="1" style="display:none"
          src="https://www.facebook.com/tr?id=892008190947941&ev=PageView&noscript=1"
        /></noscript>


<script type="text/rocketscript">
        _atrk_opts = { atrk_acct:"BUA9q1zDGU20kU", domain:"farstcoin.co",dynamic: true};
        (function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
        </script>
<noscript><img src="https://certify.alexametrics.com/atrk.gif?account=BUA9q1zDGU20kU" style="display:none" height="1" width="1" alt="" /></noscript>


<script async data-rocketsrc="https://www.googletagmanager.com/gtag/js?id=UA-70019996-6" type="text/rocketscript"></script>
<script type="text/rocketscript">
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'UA-70019996-6');
        </script>


<link rel="stylesheet" href="/tej/assets/css/normalize.css">

<link rel="stylesheet" href="/tej/assets/css/animate.css" />

<link rel="stylesheet" href="/tej/assets/css/home.css">

<link rel="stylesheet" href="/tej/assets/css/font-awesome.min.css">

<link rel="stylesheet" href="/tej/assets/css/dataTables.bootstrap.css">

<link rel="stylesheet" href="/tej/assets/css/bootstrap.min.css">


<script type="text/rocketscript" data-rocketsrc="/tej/assets/js/jQuery-2.1.3.min.js"></script>

<script type="text/rocketscript" data-rocketsrc="/tej/assets/js/bootstrap.min.js"></script>

</head>
<body>
<header class="header">
<nav class="container">
<a href="index.html" class="header__logo">
 <img src="https://farstcoin.co/resources/assets/img/home/logo_png.png" height="52" width="52" />
</a>
<button type="button" class="header__menu" id='headerCollapseButton'>
<span class="line1"></span>
<span class="line2"></span>
<span class="line3"></span>
</button>
<div class="header__full flex" id="headerCollapse">
<ul class="header__links">
<li class="header__link"><a href="https://farstcoin.co">Home</a></li>
<li class="header__link"><a href="https://signal.farstcoin.co">TOGC Signal</a></li>
<li class="header__link"><a href="https://farstcoin.co/exchange/ETH">Exchange</a></li>
<li class="header__link"><a href="https://farstcoin.co/game">Game</a></li>
<li class="header__link"><a href="https://farstcoin.co/roadmap.pdf">Road Map</a></li>
<li class="header__link"><a href="https://farstcoin.co/news">News</a></li>

<li class="header__link"><a href="https://explorer.farstcoin.co">Explorer</a></li>
<li class="header__link"><a href="https://farstcoin.co/wallets">Wallets</a></li>
</ul>
<div class="header__auth__container">
<a href="#" rel="nofollow" class="header__auth arrow" data-toggle="modal" data-target="#login-modal">Sign in</a>
<a href="https://farstcoin.co/register" rel="nofollow" class="header__auth arrow">Sign up</a>
</div>
</div>
</nav>
</header>