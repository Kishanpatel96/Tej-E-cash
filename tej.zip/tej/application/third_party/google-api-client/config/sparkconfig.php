<?php
// See the included src/config.php config file, this file is just a stub placed here to satisfy Spark requirements
?>