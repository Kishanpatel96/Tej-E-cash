<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
|  client_id         string   Your Google API Client ID.
|  client_secret     string   Your Google API Client secret.
|  redirect_uri      string   URL to redirect back to after login.
|  application_name  string   Your Google application name.
|  api_key           string   Developer key.
|  scopes            string   Specify scopes
*/
$config['google']['client_id']        = '52557591267-ul5h27kpsj61spc77jrgljltrrs9t8nh.apps.googleusercontent.com';
$config['google']['client_secret']    = 'wUkUQ1gxy2aWRSBk-bNT_H6j';
$config['google']['redirect_uri']     = 'http://localhost/tej/index.php/User_Authenticationgoogle';
$config['google']['application_name'] = 'Login to CodexWorld.com';
$config['google']['api_key']          = '';
$config['google']['scopes']           = array();